clear all; close all; clc;

%% Question 1

theta = 0:15:180;
V = [2.23, 2.214, 2.143, 2.039, 1.899, 1.735, 1.559, 1.381, 1.205, 1.059, 0.941, 0.864, 0.825];

g = -9.81*cosd(theta);

p = polyfit(g, V, 1);
plot(g, V, 'ro'); hold on;
plot(g, g*p(1) + p(2), 'b-');

legend('Raw Data', 'Best Fit');
xlabel('Tangential Acceleration'); ylabel('Measured Voltage');