load('lab5pt2.mat');
close all;



for i = 1:30
    for j = 1:15

        sig = recMatrix_sig(:, i, j);

        plot(sig); hold on;
    







    end
end